<?php
include('../config/db.php');
include('../includes/functions.php');

if (isset($_GET['token'])) {
    $token = $_GET['token'];
    $query = "SELECT * FROM users WHERE activation_code='$token' LIMIT 1";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 0) {
        echo "<script>alert('Token tidak valid!'); window.location='password.php';</script>";
        exit;
    }
} else {
    echo "<script>alert('Token tidak ditemukan!'); window.location='password.php';</script>";
    exit;
}

if (isset($_POST['update_password'])) {
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $update = "UPDATE users SET password='$password', activation_code='' WHERE activation_code='$token'";
    if (mysqli_query($conn, $update)) {
        echo "<script>alert('Password berhasil diubah! Silakan login.'); window.location='login.php';</script>";
    } else {
        echo "<script>alert('Gagal mengubah password!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Reset Password</title>
</head>
<body>
<h2>Reset Password Baru</h2>
<form method="POST">
    Password Baru:<br>
    <input type="password" name="password" required><br><br>
    <button type="submit" name="update_password">Ubah Password</button>
</form>
</body>
</html>
