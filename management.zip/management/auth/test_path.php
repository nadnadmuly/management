<?php
include __DIR__ . '/../config/db.php';
include __DIR__ . '/../includes/functions.php';

echo "Koneksi dan include berhasil!";
?>
