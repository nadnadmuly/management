<?php
header("Location: auth/login.php");
exit;
?>
